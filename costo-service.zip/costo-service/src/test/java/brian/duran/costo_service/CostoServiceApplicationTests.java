package brian.duran.costo_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
